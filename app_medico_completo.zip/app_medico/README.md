# App Médico - Renovação de Receitas

## Passo a Passo para Deploy

### 1. Criar Repositório no GitHub
1. Acesse https://github.com/new
2. Nome: `app-medico`
3. Visibilidade: Private
4. NÃO inicialize com README
5. Clique em "Create repository"

### 2. Upload dos Arquivos
1. Extraia o ZIP
2. No GitHub, clique em "uploading an existing file"
3. Arraste TODOS os arquivos e pastas
4. Commit: "Initial commit"

### 3. Conectar ao Render
1. Acesse https://render.com
2. New → Web Service
3. Conecte seu GitHub
4. Selecione `app-medico`
5. O Render detectará automaticamente o render.yaml

### 4. Configurar Variáveis de Ambiente no Render
- `DATABASE_URL`: URL do Neon (postgres://...)
- `MERCADOPAGO_ACCESS_TOKEN`: Token do Mercado Pago
- `MERCADOPAGO_PUBLIC_KEY`: Chave pública do Mercado Pago
- `R2_ACCESS_KEY_ID`: Access Key do Cloudflare R2
- `R2_SECRET_ACCESS_KEY`: Secret Key do Cloudflare R2
- `R2_BUCKET_NAME`: Nome do bucket
- `R2_ENDPOINT_URL`: URL do endpoint R2
- `OPENROUTER_API_KEY`: Chave da OpenRouter

### 5. Deploy
- Clique em "Create Web Service"
- Aguarde o deploy (5-10 minutos)

### 6. Configurar Banco de Dados
Acesse: `https://seu-app.onrender.com/setup-db`

### 7. Upload do Certificado Digital
Acesse: `https://seu-app.onrender.com/admin/upload-certificate`

### 8. Configurar Webhook do Mercado Pago
URL: `https://seu-app.onrender.com/webhook/mercadopago`

## Pronto! 🎉
Seu app estará rodando em: `https://seu-app.onrender.com`
