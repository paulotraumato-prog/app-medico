from fastapi import FastAPI, Depends, HTTPException, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from datetime import timedelta
import mercadopago
import boto3
from openai import OpenAI
from .database import get_db, init_db, User, Case, Certificate
from .auth import get_password_hash, verify_password, create_access_token, get_current_user
from .config import *
import os

app = FastAPI(title="App Médico")

# Templates
templates = Jinja2Templates(directory="app/templates")

# Inicializar serviços
mp = mercadopago.SDK(MERCADOPAGO_ACCESS_TOKEN) if MERCADOPAGO_ACCESS_TOKEN else None
s3_client = boto3.client(
    's3',
    endpoint_url=R2_ENDPOINT_URL,
    aws_access_key_id=R2_ACCESS_KEY_ID,
    aws_secret_access_key=R2_SECRET_ACCESS_KEY
) if R2_ACCESS_KEY_ID else None

openai_client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY
) if OPENROUTER_API_KEY else None

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Email ou senha incorretos")

    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )

    response = RedirectResponse(url=f"/{user.user_type}/dashboard", status_code=303)
    response.set_cookie(key="access_token", value=f"Bearer {access_token}", httponly=True)
    return response

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register(
    email: str = Form(...),
    password: str = Form(...),
    full_name: str = Form(...),
    user_type: str = Form(...),
    cpf: str = Form(...),
    phone: str = Form(...),
    crm: str = Form(None),
    crm_uf: str = Form(None),
    db: Session = Depends(get_db)
):
    existing_user = db.query(User).filter(User.email == email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email já cadastrado")

    user = User(
        email=email,
        hashed_password=get_password_hash(password),
        full_name=full_name,
        user_type=user_type,
        cpf=cpf,
        phone=phone,
        crm=crm if user_type == "doctor" else None,
        crm_uf=crm_uf if user_type == "doctor" else None
    )
    db.add(user)
    db.commit()

    return RedirectResponse(url="/login", status_code=303)

@app.get("/patient/dashboard", response_class=HTMLResponse)
async def patient_dashboard(request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("access_token")
    if not token:
        return RedirectResponse(url="/login")

    try:
        user = get_current_user(token.replace("Bearer ", ""), db)
        if user.user_type != "patient":
            raise HTTPException(status_code=403)

        cases = db.query(Case).filter(Case.patient_id == user.id).order_by(Case.created_at.desc()).all()
        return templates.TemplateResponse("patient_dashboard.html", {
            "request": request,
            "user": user,
            "cases": cases
        })
    except:
        return RedirectResponse(url="/login")

@app.get("/patient/new-case", response_class=HTMLResponse)
async def new_case_page(request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("access_token")
    if not token:
        return RedirectResponse(url="/login")

    try:
        user = get_current_user(token.replace("Bearer ", ""), db)
        if user.user_type != "patient":
            raise HTTPException(status_code=403)

        return templates.TemplateResponse("new_case.html", {"request": request, "user": user})
    except:
        return RedirectResponse(url="/login")

@app.post("/patient/new-case")
async def create_case(
    case_type: str = Form(...),
    description: str = Form(...),
    request: Request = None,
    db: Session = Depends(get_db)
):
    token = request.cookies.get("access_token")
    user = get_current_user(token.replace("Bearer ", ""), db)

    case = Case(
        patient_id=user.id,
        case_type=case_type,
        description=description,
        status="pending",
        amount=50.0
    )
    db.add(case)
    db.commit()
    db.refresh(case)

    # Criar preferência de pagamento no Mercado Pago
    if mp:
        preference_data = {
            "items": [
                {
                    "title": f"{'Receita' if case_type == 'receita' else 'Relatório'} Médico",
                    "quantity": 1,
                    "unit_price": case.amount
                }
            ],
            "back_urls": {
                "success": f"{request.base_url}payment/success",
                "failure": f"{request.base_url}payment/failure",
                "pending": f"{request.base_url}payment/pending"
            },
            "auto_return": "approved",
            "external_reference": str(case.id)
        }
        preference_response = mp.preference().create(preference_data)
        payment_url = preference_response["response"]["init_point"]

        case.payment_id = preference_response["response"]["id"]
        db.commit()

        return RedirectResponse(url=payment_url, status_code=303)

    return RedirectResponse(url="/patient/dashboard", status_code=303)

@app.get("/doctor/dashboard", response_class=HTMLResponse)
async def doctor_dashboard(request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("access_token")
    if not token:
        return RedirectResponse(url="/login")

    try:
        user = get_current_user(token.replace("Bearer ", ""), db)
        if user.user_type != "doctor":
            raise HTTPException(status_code=403)

        cases = db.query(Case).filter(Case.status == "in_review").order_by(Case.created_at.desc()).all()
        return templates.TemplateResponse("doctor_dashboard.html", {
            "request": request,
            "user": user,
            "cases": cases
        })
    except:
        return RedirectResponse(url="/login")

@app.get("/doctor/case/{case_id}", response_class=HTMLResponse)
async def view_case(case_id: int, request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("access_token")
    if not token:
        return RedirectResponse(url="/login")

    try:
        user = get_current_user(token.replace("Bearer ", ""), db)
        if user.user_type != "doctor":
            raise HTTPException(status_code=403)

        case = db.query(Case).filter(Case.id == case_id).first()
        if not case:
            raise HTTPException(status_code=404)

        return templates.TemplateResponse("case_detail.html", {
            "request": request,
            "user": user,
            "case": case
        })
    except:
        return RedirectResponse(url="/login")

@app.post("/doctor/case/{case_id}/approve")
async def approve_case(case_id: int, request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("access_token")
    user = get_current_user(token.replace("Bearer ", ""), db)

    if user.user_type != "doctor":
        raise HTTPException(status_code=403)

    case = db.query(Case).filter(Case.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404)

    # Assinar documento e fazer upload
    # TODO: Implementar assinatura digital

    case.status = "completed"
    case.doctor_id = user.id
    db.commit()

    return RedirectResponse(url="/doctor/dashboard", status_code=303)

@app.post("/doctor/case/{case_id}/reject")
async def reject_case(
    case_id: int,
    reason: str = Form(...),
    request: Request = None,
    db: Session = Depends(get_db)
):
    token = request.cookies.get("access_token")
    user = get_current_user(token.replace("Bearer ", ""), db)

    if user.user_type != "doctor":
        raise HTTPException(status_code=403)

    case = db.query(Case).filter(Case.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404)

    case.status = "rejected"
    case.rejection_reason = reason
    case.doctor_id = user.id
    db.commit()

    return RedirectResponse(url="/doctor/dashboard", status_code=303)

@app.post("/webhook/mercadopago")
async def mercadopago_webhook(request: Request, db: Session = Depends(get_db)):
    data = await request.json()

    if data.get("type") == "payment":
        payment_id = data["data"]["id"]
        payment_info = mp.payment().get(payment_id)

        if payment_info["response"]["status"] == "approved":
            external_reference = payment_info["response"]["external_reference"]
            case = db.query(Case).filter(Case.id == int(external_reference)).first()

            if case:
                case.payment_status = "approved"
                case.status = "in_review"

                # Gerar documento com IA
                if openai_client:
                    prompt = f"Gere uma {'receita médica' if case.case_type == 'receita' else 'relatório médico'} baseado na seguinte descrição: {case.description}"
                    response = openai_client.chat.completions.create(
                        model="openai/gpt-3.5-turbo",
                        messages=[{"role": "user", "content": prompt}]
                    )
                    case.ai_generated_document = response.choices[0].message.content

                db.commit()

    return {"status": "ok"}

@app.get("/setup-db")
async def setup_database():
    try:
        init_db()
        return {"message": "Database initialized successfully"}
    except Exception as e:
        return {"error": str(e)}

@app.get("/admin/upload-certificate", response_class=HTMLResponse)
async def upload_certificate_page(request: Request):
    return templates.TemplateResponse("upload_certificate.html", {"request": request})

@app.post("/admin/upload-certificate")
async def upload_certificate(
    certificate: UploadFile = File(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    # Salvar certificado
    os.makedirs("certificates", exist_ok=True)
    file_path = f"certificates/{certificate.filename}"

    with open(file_path, "wb") as f:
        f.write(await certificate.read())

    # Desativar certificados anteriores
    db.query(Certificate).update({"is_active": False})

    # Salvar novo certificado
    cert = Certificate(file_path=file_path, password=password)
    db.add(cert)
    db.commit()

    return {"message": "Certificado enviado com sucesso"}

@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/login")
    response.delete_cookie("access_token")
    return response
